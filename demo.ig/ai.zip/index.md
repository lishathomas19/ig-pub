# Home - Lisha Demo Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://lishathomas19.github.io/ig-pub/demo.ig/ImplementationGuide/demo.ig | *Version*:1.0.0 |
| Active as of 2026-01-03 | *Computable Name*:DemoImplementationGuide |

# Demo IG

This is my first FHIR Implementation Guide.

It includes one example Patient resource.

